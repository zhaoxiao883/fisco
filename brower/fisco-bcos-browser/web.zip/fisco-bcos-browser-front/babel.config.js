module.exports = {
	presets: [
		
		["@babel/preset-env", {
			modules: false,
			corejs: 3,					//corejs的版本   3是支持es6-9的， 2只支持es5和部分es6
			useBuiltIns: "usage",		//让babel按需引入兼容的es
			debug: false
		}]
	],
	// 转译箭头函数
	plugins: ["@babel/plugin-transform-arrow-functions"]
}
