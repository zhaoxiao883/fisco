# fisco-bcos浏览器前端

本项目是fisco-bcos浏览器，使用框架`vue-cli`。

兼容浏览器IE9及以上，360浏览器兼容版（IE9内核），360浏览器极速版，qq浏览器急速模式（chrome内核），chrome浏览器。

详细了解,请阅读[**技术文档**](https://fisco-bcos-documentation.readthedocs.io/zh_CN/latest/docs/browser/web.html)。