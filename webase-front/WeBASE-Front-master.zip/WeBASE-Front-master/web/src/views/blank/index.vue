<template>
    <div></div>
</template>

<script>
export default {
    name: '',

    components: {
    },

    props: {
    },

    data() {
        return {
        }
    },

    computed: {
    },

    watch: {
    },

    created() {
    },

    mounted() {
        this.$router.go(-1)
    },

    methods: {
    }
}
</script>

<style scoped>
</style>
