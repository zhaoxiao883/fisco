package com.webank.webase.front.contract.entity;

import lombok.Data;

@Data
public class RepCopyContractItem {
    private String contractName;
    private String contractSource;
}
